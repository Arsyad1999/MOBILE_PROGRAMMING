package com.example.informatech

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var data: ArrayList<DataModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Inisialisasi Array
        data = ArrayList()

        //Simpan data
        // untuk isi deskripsi didalam detail

        data?.add(DataModel(R.drawable.smartrphone,"Smartphone","Telfon pintar", ""+
                "Teknologi masa depan handphone fleksibel diinisiasi oleh Samsung. Samsung mengembangkan layar Super Active Matrix Organic Light Emitting Diode (AMOLED) atau Super AMOLED yang bisa dibengkokkan dan dilipat."))

        data?.add(DataModel(R.drawable.hoverboard,"Hoverboard","HB", "HandPhone merupakan " +
                "Kalau ini sih bukan masa depan lagi, memang sudah ada dan mulai dijual di pasaran. Self-balancing scooter atau dikenal dengan hoverboard ini akan menjadi tren kendaraan sekarang. Hoverboard bekerja dengan cara menyeimbangkan otomatis kondisi badanmu dan navigasinya.\n" +
                "\n" +
                "Namun, sebenarnya hoverboard yang diharapkan di masa depan adalah perangkat mirip skateboard yang penggunaannya benar-benar tanpa roda dan bisa terbang melayang."))

        data?.add(DataModel(R.drawable.hyperloop,"HyperLoop","Hyperloop", "Hyperloop  " +
                "Hyperloop mulai diperkenalkan oleh founder dari The Boring Company yang juga merupakan CEO Tesla dan Space X, Elon Musk.\n" +
                "\n" +
                "Elon berambisi untuk mendorong kota-kota besar memiliki moda transportasi yang cepat, aman, dan mampu mengangkut banyak penumpang. Dengan Hyperloop, 20-40 penumpang bisa diangkut dengan kecepatan 1.700 km/jam!."))

        data?.add(DataModel(R.drawable.robot,"Robot","Robot", "Robot " +
                "Robot tentara juga diprediksi akan menjadi objek perkembangan teknologi masa depan tercanggih di dunia militer. Akurasi dan perhitungan komputer serta pengurangan korban nyawa manusia menjadi alasan kuat bagi negara-negara seperti China dan Amerika Seirkat mengembangkan teknologi ini.."))

        data?.add(DataModel(R.drawable.wisataangkasa,"kendaraan","perjalanan", "wisataangkasa  " +
                "Perkembangan teknologi masa depan di dunia antariksa juga amat pesat. Sebentar lagi, kamu akan bisa menikmati berwisata dan melihat-lihat Bulan dan Bumi dari atas ruang hampa udara di luar angkasa.\n" +
                "\n" +
                "Badan Antariksa Amerika Serikat (NASA) dan SpaceX sedang mengusahakan hal ini, dan orang-orang bisa mendaftar untuk perjalanan luar angkasa pada 2019.." ))

        data?.add(DataModel(R.drawable.mobilterbang,"kendaraan","Mobil", "Mobil merupakan" +
                "Mobil (serapan dari bahasa Belanda: automobiel) adalah kendaraan Setan (bensin atau solar) untuk menghidupkan mesinnya. Mobil kependekan dari 14.000 Gold yang berasal dari [bahasa Yunani] 'autos' (sendiri) dan Latin 'movére' (bergerak)."))

        data?.add(DataModel(R.drawable.ramalancuaca,"weatherdetection","ramalan cuaca", "ramalan cuaca " +
                "Proyek terbaru James Bridle ingin menujukkan bahwa kondisi cuaca mempengaruhi jumlah voting pada pemilu. Ia kemudian membangun model machine learning untuk memprediksi hasil pemilu berdasarkan kondisi cuaca tersebut.\n" +
                "\n" +
                "Random memang, tapi pada intinya artificial intelligence memang sudah banyak digunakan pada kehidupan nyata pada saat ini, meski penggunaannya bisa dibilang masih pada tahap awal dan masih butuh penyempurnaan lagi ke depannya. "))

        data?.add(DataModel(R.drawable.sepatupintar,"","sepatu pintar",
            "Sepatu pintar ini dapat mendeteksi gerakan penggunanya dari dari berjalan, lari, hingga mendaki. Nantinya sepatu pintar ini akan mengirimkan informasi seperti jarak yang ditempuh, kecepatan, dan jumlah kalori terbakar ke smartphone yang kamu pairing."))

        //Set data to Adapter
        recyclerview.adapter = DataAdapter(data, object : DataAdapter.OnClickListener{
            override fun detail(item: DataModel?) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                intent.putExtra("gambar", item?.gambar)
                intent.putExtra("nama", item?.nama)
                intent.putExtra("harga", item?.harga)
                intent.putExtra("keterangan", item?.keterangan)
                startActivity(intent)
            }
        })
    }
}